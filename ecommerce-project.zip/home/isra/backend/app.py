import os
from flask import Flask, jsonify, request

app = Flask(__name__)


UPLOAD_FOLDER = "/var/log/ecommerce/"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route("/api/upload", methods=["POST"])
def upload_log():
    if "logfile" not in request.files:
        return jsonify({"message": "No file uploaded"}), 400

    file = request.files["logfile"]
    filepath = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(filepath)

    return jsonify({"message": f"File {file.filename} uploaded successfully"}), 200


@app.route("/api/hello", methods=["GET"])
def hello():
    return jsonify({"message": "Backend Flask OK!"})
